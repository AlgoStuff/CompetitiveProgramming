<?php
function compare($S1,$S2,$limit)
{
  $S1=strtolower($S1);$S2=strtolower($S2);
  $n=strlen($S1);$m=strlen($S2);
  if($S1==$S2)
	return 0;
  if($limit==null)
	$limit=9999998;
  if(abs($n-$m)>$limit)
    return 9999999;
  if(!$n)
	return $m;
  if(!$m)
	return $n;
  $dist=array_fill(0,2,array_fill(0,$m+1,0)); $ok=1; $current=1;
  for($i=1;$i<=$m;$i++)
  {	
	  $dist[0][$i]=$i;
  }
  for($i=1;$i<=$n;$i++)
  {
    $ok=0;
    $dist[$current][0]=$i;
    if($i-$limit>=1)
		$dist[$current][$i-$limit-1]=9999999;
    for($j=max($i-$limit,1);$j<=min($i+$limit,$m);$j++)
    {
        if(substr($S1,$i-1,1)==substr($S2,$j-1,1))
            $dist[$current][$j]=$dist[1-$current][$j-1];
        else
            $dist[$current][$j]=min($dist[1-$current][$j-1],$dist[1-$current][$j],$dist[$current][$j-1])+1;
        if($dist[$current][$j]<=$limit)
            $ok=1;
    }
    if($i+$limit<=$m)
    {
		$dist[$current][$i+$limit+1]=9999999;
	}
    if(!$ok)
    {
        return 9999999;
	}
    $current=1-$current;
  }
  return $dist[1-$current][$m];
}
?>
