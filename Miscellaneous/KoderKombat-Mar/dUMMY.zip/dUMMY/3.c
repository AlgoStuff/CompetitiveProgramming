#include<stdio.h>

int main(){
	int i;
	printf("100\n");
	for(i=1;i<=100;i++)
		printf("%d\n",i);
}
